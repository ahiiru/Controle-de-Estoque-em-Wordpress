# Controle-de-Estoque-em-Wordpress

O banco de dados est� na pasta db/

Para acessar o painel do Wordpress:
Login: adm_altran
Senha: 1jwiTiC6Hbz(*wcd&V
